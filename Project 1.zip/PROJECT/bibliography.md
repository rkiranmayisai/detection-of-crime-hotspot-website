# 10. BIBLIOGRAPHY

## 10.1 Academic Research & Journals
*   **Bogomolov, A., Lepri, B., Staiano, J., Oliver, N., Pianesi, F., & Pentland, A. (2014).** "Once Upon a Crime: Towards Crime Prediction from Demographics and Mobile Data." *Proceedings of the 16th International Conference on Multimodal Interaction (ICMI)*.
*   **Cinnamon, J., & Schuurman, N. (2012).** "Facilitated Volunteered Geographic Information (VGI) in Health and Safety." *ACME: An International Journal for Critical Geographies*.
*   **Chainey, S., & Ratcliffe, J. (2013).** *GIS and Crime Mapping*. John Wiley & Sons. (Foundational text for spatial-temporal crime analysis).
*   **Goodchild, M. F. (2007).** "Citizens as sensors: the world of volunteered geographic information." *GeoJournal*.
*   **Ratcliffe, J. H. (2010).** "Crime Mapping: Progress and Problems." *Theoretical Criminology*.

## 10.2 Technical Documentation & Frameworks
*   **Flask Documentation (3.x)**: Official guide for building scalable web applications with Python. [https://flask.palletsprojects.com/](https://flask.palletsprojects.com/)
*   **Leaflet.js API Reference**: Documentation for interactive mapping and heatmap virtualization. [https://leafletjs.com/reference.html](https://leafletjs.com/reference.html)
*   **SQLite official Documentation**: Engine specifications for lightweight relational database management. [https://www.sqlite.org/docs.html](https://www.sqlite.org/docs.html)
*   **Haversine Formula**: Mathematical formulations for great-circle distances between points on a sphere. [https://en.wikipedia.org/wiki/Haversine_formula](https://en.wikipedia.org/wiki/Haversine_formula)
*   **Python Software Foundation**: Standard Library and sqlite3 module references. [https://docs.python.org/3/](https://docs.python.org/3/)

## 10.3 Development Tools & Resources
*   **Postman**: Used for RESTful API developmental testing and performance benchmarking.
*   **Chrome Developer Tools**: Primary tool for frontend debugging and CSS performance optimization.
*   **OpenStreetMap (OSM)**: Source for high-resolution base map tiles and geographical metadata. [https://www.openstreetmap.org/](https://www.openstreetmap.org/)
*   **Leaflet.heat Plugin**: Documentation for the dynamic spectral heatmap rendering used in this project. [https://github.com/Leaflet/Leaflet.heat](https://github.com/Leaflet/Leaflet.heat)

## 10.4 Typography & Visual Assets
*   **Leaflet Color Markers**: Custom marker assets for map status visualization. [https://github.com/pointhi/leaflet-color-markers](https://github.com/pointhi/leaflet-color-markers)
*   **Google Fonts**: Outfit and Inter typography for industrial UI design.
